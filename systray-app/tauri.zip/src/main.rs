#![cfg_attr(
  all(not(debug_assertions), target_os = "windows"),
  windows_subsystem = "windows"
)]

use tauri::{CustomMenuItem, SystemTray, SystemTrayMenu, SystemTrayMenuItem, SystemTrayEvent
            };
use tauri::Manager;

fn main() {

  let show = CustomMenuItem::new("show".to_string(), "Show");
  let new = CustomMenuItem::new("new".to_string(), "Config");
  let close = CustomMenuItem::new("close".to_string(), "Close");
  let quit = CustomMenuItem::new("quit".to_string(), "Quit");

  let tray_menu = SystemTrayMenu::new()
  .add_item(show)
  .add_native_item(SystemTrayMenuItem::Separator)
  .add_item(new)
  .add_native_item(SystemTrayMenuItem::Separator)
  .add_item(close)
  .add_native_item(SystemTrayMenuItem::Separator)
  .add_item(quit);

  tauri::Builder::default()
  .system_tray(SystemTray::new().with_menu(tray_menu))
    .on_system_tray_event(|app, event| match event {
      
      SystemTrayEvent::MenuItemClick { id, .. } => {
        match id.as_str() { 
          "show" => {
            let window = app.get_window("main").unwrap();
            window.eval("window.location.replace('/')");
            window.show().unwrap();
          }        

          "new" => {
            /*To open a new window in Tauri app
            WindowBuilder::new(app, "new", WindowUrl::App("/config".into()))
              .title("Tauri")
              .build()
              .unwrap();
            */
            let window = app.get_window("main").unwrap();            
            window.eval("window.location.replace('/config')");
            window.show().unwrap();
          } 
          "close" => {
            let window = app.get_window("main").unwrap();
            window.hide().unwrap();
          }
          "quit" => {
            app.exit(0);

          }          
          _ => {}
        }
      }
      _ => {}
    })
    .run(tauri::generate_context!())
    .expect("error while running tauri application");
}

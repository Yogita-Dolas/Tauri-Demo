export default function NotFound(){
    return(
        <h1>PAGE NOT FOUND</h1>
    )
}